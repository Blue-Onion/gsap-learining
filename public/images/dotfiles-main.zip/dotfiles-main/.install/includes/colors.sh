#!/bin/bash
RED='\033[0;31m'   #'0;31' is Red
GREEN='\033[0;32m'   #'0;32' is Green
YELLOW='\033[1;32m'   #'1;32' is Yellow
BLUE='\033[0;34m'   #'0;34' is Blue
NONE='\033[0m'      # NO COLOR
