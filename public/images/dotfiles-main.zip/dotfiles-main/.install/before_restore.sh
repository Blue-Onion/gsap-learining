# ------------------------------------------------------
# Modify existing files before restore starts
# ------------------------------------------------------

if [ -d ~/dotfiles ] ;then
    echo ":: Modify existing files"
fi