echo -e "${GREEN}"
figlet "General"
echo -e "${NONE}"