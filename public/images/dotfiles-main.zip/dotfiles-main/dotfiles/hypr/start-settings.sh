#!/bin/bash
$HOME/dotfiles/apps/ML4W_Dotfiles_Settings-x86_64.AppImage