#!/bin/bash
sleep 0.3
$HOME/dotfiles/eww/ml4w-sidebar/launch.sh