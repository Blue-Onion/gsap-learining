#!/bin/bash
theme_name="ML4W Blur Bottom Light"
