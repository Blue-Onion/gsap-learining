#!/bin/bash
theme_name="Waybar Default Theme"
