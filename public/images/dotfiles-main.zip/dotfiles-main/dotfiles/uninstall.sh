#!/bin/bash
#  _   _       _           _        _ _ 
# | | | |_ __ (_)_ __  ___| |_ __ _| | |
# | | | | '_ \| | '_ \/ __| __/ _` | | |
# | |_| | | | | | | | \__ \ || (_| | | |
#  \___/|_| |_|_|_| |_|___/\__\__,_|_|_|
#                                      
clear
sleep 1
cp $HOME/dotfiles/apps/ML4W_Dotfiles_Uninstaller.AppImage $HOME/.cache
cd $HOME/.cache
./ML4W_Dotfiles_Uninstaller.AppImage